Retrieves the ingredients, quantities and units after input a recipe.
